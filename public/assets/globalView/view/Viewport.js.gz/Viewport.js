/*
 * File: BiofuelsGlobal/view/Viewport.js
 */
//------------------------------------------------------------------------------
Ext.define("BiofuelsGlobal.view.Viewport",{extend:"BiofuelsGlobal.view.MainViewport",requires:["BiofuelsGlobal.view.MainViewport"],renderTo:Ext.getBody()});