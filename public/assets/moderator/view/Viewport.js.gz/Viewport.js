/*
 * File: BiofuelsModerator/view/Viewport.js
 */
//------------------------------------------------------------------------------
Ext.define("BiofuelsModerator.view.Viewport",{extend:"BiofuelsModerator.view.MainViewport",requires:["BiofuelsModerator.view.MainViewport"],renderTo:Ext.getBody()});