/*
 * File: app.js
 */
Ext.define("WsConnection",{singleton:!0,id:"",gameChannel:""}),Ext.Loader.setConfig({enabled:!0}),Ext.application({autoCreateViewport:!0,name:"Biofuels",appFolder:"/assets/playerClient"});