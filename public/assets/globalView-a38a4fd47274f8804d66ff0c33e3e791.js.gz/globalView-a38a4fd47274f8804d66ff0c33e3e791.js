/*
 * File: app.js
 */
Ext.Loader.setConfig({enabled:!0}),Ext.application({autoCreateViewport:!0,name:"BiofuelsGlobal",appFolder:"/assets/globalView",init:function(e){},launch:function(e){}});